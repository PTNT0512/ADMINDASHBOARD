import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Volume2, VolumeX, Play, Square, Shield, Clock, Zap, Target, TrendingUp, Trophy, History } from 'lucide-react';

// --- Cấu hình hằng số Game ---
const GRAVITY = 0.38; 
const BOUNCE_DAMPENING = 0.45;
const HORIZONTAL_RANDOMNESS = 0.25;
const AUTO_DROP_INTERVAL = 150; 

const COLORS = {
  bg: '#05070a',
  pin: '#475569',
  ball: '#ef4444',
  ballSuper: '#38bdf8',
  ballMega: '#f59e0b',
  highMult: '#7f1d1d',
  medMult: '#92400e',
  lowMult: '#064e3b',
  gate: '#38bdf8',
  text: '#10b981'
};

const FIXED_ROW_COUNT = 14;
const FIXED_MULTIPLIERS = [100, 25, 12, 6, 2, 1.2, 0.5, 0.2, 0.5, 1.2, 2, 6, 12, 25, 100];

export default function App() {
  // --- State Game ---
  const [balance, setBalance] = useState(10000000);
  const [bet, setBet] = useState(10000);
  const [history, setHistory] = useState([]); // Chứa danh sách kết quả chi tiết
  const [isMuted, setIsMuted] = useState(false);
  const [isAuto, setIsAuto] = useState(false);
  const [message, setMessage] = useState("HỆ THỐNG SẴN SÀNG");
  const [stats, setStats] = useState({ totalDrops: 0, totalWins: 0 });

  const canvasRef = useRef(null);
  const requestRef = useRef(null);
  const audioCtxRef = useRef(null);
  
  const gameState = useRef({
    width: 0,
    height: 0,
    balls: [],
    pins: [],
    particles: [],
    multipliers: [],
    gates: [],
    layoutGap: 20,
    pegSize: 2.5,
    ballSize: 6,
    lastTime: 0,
    autoEnabled: false,
    lastAutoDrop: 0,
    currentBalance: 10000000,
    currentBet: 10000,
    startY: 60
  });

  useEffect(() => { gameState.current.currentBalance = balance; }, [balance]);
  useEffect(() => { gameState.current.currentBet = bet; }, [bet]);
  useEffect(() => { gameState.current.autoEnabled = isAuto; }, [isAuto]);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtxRef.current = new AudioContext();
    }
    if (audioCtxRef.current.state === 'suspended') audioCtxRef.current.resume();
  };

  const playSound = useCallback((type) => {
    if (isMuted || !audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const now = ctx.currentTime;

    if (type === 'hit') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(300 + Math.random() * 200, now);
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === 'gate') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gain.gain.setValueAtTime(0.02, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    }
  }, [isMuted]);

  const createParticles = (x, y, color, count = 5) => {
    for (let i = 0; i < count; i++) {
      gameState.current.particles.push({
        x, y,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        life: 1.0,
        color
      });
    }
  };

  const generateLayout = useCallback(() => {
    const state = gameState.current;
    if (!state.width || !state.height) return;

    const { width, height } = state;
    state.pins = [];
    state.multipliers = [];
    state.gates = [];

    const pinsInLastRow = FIXED_ROW_COUNT + 2;
    const paddingX = 20; 
    const paddingY = 280; 
    
    let gap = Math.min((width - paddingX) / (pinsInLastRow + 1), (height - paddingY) / FIXED_ROW_COUNT);
    gap = Math.max(16, Math.min(gap, 26));

    state.layoutGap = gap;
    state.ballSize = gap * 0.28;
    state.startY = 40;

    for (let r = 0; r < FIXED_ROW_COUNT; r++) {
      const pinsInRow = r + 3;
      const rowWidth = (pinsInRow - 1) * gap;
      const startX = (width - rowWidth) / 2;
      for (let c = 0; c < pinsInRow; c++) {
        state.pins.push({ x: startX + c * gap, y: state.startY + r * gap, pulse: 0 });
      }
    }

    state.gates.push({
      x: width / 2 - gap,
      y: state.startY + 6 * gap,
      w: gap * 2,
      h: gap * 0.6,
      pulse: 0,
      minX: gap * 1.5, 
      maxX: width - gap * 3.5,
      direction: 1, 
      speed: 1.2,
      type: 'multiplier'
    });

    const bucketW = gap;
    const totalW = FIXED_MULTIPLIERS.length * bucketW;
    const startXMult = (width - totalW) / 2;

    FIXED_MULTIPLIERS.forEach((val, i) => {
      let color = val >= 20 ? COLORS.highMult : (val >= 2 ? COLORS.medMult : COLORS.lowMult);
      state.multipliers.push({
        x: startXMult + i * bucketW,
        y: height - 100, 
        w: bucketW,
        h: 30,
        value: val,
        color: color,
        pulse: 0
      });
    });
  }, []);

  const executeDrop = useCallback((betAmount) => {
    const state = gameState.current;
    state.balls.push({
      x: state.width / 2 + (Math.random() - 0.5) * 6,
      y: state.startY - 20,
      vx: (Math.random() - 0.5) * 0.4,
      vy: 2,
      radius: state.ballSize,
      betValue: betAmount,
      currentMult: 1,
      hitGates: [],
      history: []
    });
    setStats(s => ({ ...s, totalDrops: s.totalDrops + 1 }));
  }, []);

  const update = (time) => {
    const state = gameState.current;
    state.lastTime = time;

    if (state.autoEnabled && time - state.lastAutoDrop > AUTO_DROP_INTERVAL) {
      if (state.currentBalance >= state.currentBet) {
        setBalance(b => {
          const newB = b - state.currentBet;
          gameState.current.currentBalance = newB;
          return newB;
        });
        executeDrop(state.currentBet);
        state.lastAutoDrop = time;
      } else {
        setIsAuto(false);
      }
    }

    state.gates.forEach(g => {
      g.x += g.direction * g.speed;
      if (g.x <= g.minX || g.x >= g.maxX) g.direction *= -1;
    });

    for (let i = state.particles.length - 1; i >= 0; i--) {
      const p = state.particles[i];
      p.x += p.vx; p.y += p.vy; p.life -= 0.025;
      if (p.life <= 0) state.particles.splice(i, 1);
    }

    const bucketW = state.layoutGap;
    const totalW = FIXED_MULTIPLIERS.length * bucketW;
    const startXMult = (state.width - totalW) / 2;

    for (let i = state.balls.length - 1; i >= 0; i--) {
      let b = state.balls[i];
      b.vy += GRAVITY;
      b.x += b.vx; 
      b.y += b.vy;

      if (b.x < b.radius || b.x > state.width - b.radius) {
        b.vx *= -0.5;
        b.x = b.x < b.radius ? b.radius : state.width - b.radius;
      }

      state.gates.forEach((g, idx) => {
        if (b.x > g.x && b.x < g.x + g.w && b.y > g.y && b.y < g.y + g.h && !b.hitGates.includes(idx)) {
          b.hitGates.push(idx);
          b.currentMult *= 2;
          g.pulse = 1;
          playSound('gate');
          createParticles(b.x, b.y, COLORS.gate, 8);
        }
      });

      state.pins.forEach(p => {
        const dx = b.x - p.x;
        const dy = b.y - p.y;
        const distSq = dx * dx + dy * dy;
        const minDist = b.radius + state.pegSize;
        if (distSq < minDist * minDist) {
          p.pulse = 1;
          playSound('hit');
          const dist = Math.sqrt(distSq);
          const nx = dx / dist;
          const ny = dy / dist;
          const speed = Math.sqrt(b.vx * b.vx + b.vy * b.vy) * BOUNCE_DAMPENING;
          b.vx = Math.cos(Math.atan2(ny, nx) + (Math.random() - 0.5) * HORIZONTAL_RANDOMNESS) * speed;
          b.vy = Math.sin(Math.atan2(ny, nx)) * speed;
          b.x = p.x + nx * (minDist + 0.1);
          b.y = p.y + ny * (minDist + 0.1);
        }
      });

      if (b.y > state.height - 100) {
        const idx = Math.floor((b.x - startXMult) / bucketW);
        const mIdx = Math.max(0, Math.min(idx, state.multipliers.length - 1));
        const m = state.multipliers[mIdx];
        const finalMult = m.value * b.currentMult;
        const totalWin = b.betValue * finalMult;
        
        setBalance(prev => prev + totalWin);
        setStats(s => ({ ...s, totalWins: s.totalWins + totalWin }));
        
        // Cập nhật lịch sử dạng card
        const logId = Math.random();
        setHistory(prev => [{ 
            id: logId, 
            mult: finalMult.toFixed(1), 
            win: totalWin.toLocaleString(),
            color: m.color 
        }, ...prev].slice(0, 10));
        
        m.pulse = 1;
        createParticles(b.x, state.height - 100, m.color, 12);
        state.balls.splice(i, 1);
      }
    }
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const state = gameState.current;
    
    ctx.clearRect(0, 0, state.width, state.height);

    // Vẽ Đinh
    state.pins.forEach(p => {
      ctx.fillStyle = p.pulse > 0 ? '#60a5fa' : '#475569';
      ctx.beginPath();
      ctx.arc(p.x, p.y, state.pegSize + (p.pulse * 2), 0, Math.PI * 2);
      ctx.fill();
      if (p.pulse > 0) p.pulse -= 0.08;
    });

    // Vẽ Cổng
    state.gates.forEach(g => {
      ctx.strokeStyle = COLORS.gate;
      ctx.lineWidth = 1;
      ctx.strokeRect(g.x, g.y, g.w, g.h);
      ctx.fillStyle = `rgba(56, 189, 248, ${0.1 + g.pulse * 0.3})`;
      ctx.fillRect(g.x, g.y, g.w, g.h);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 9px Inter';
      ctx.textAlign = 'center';
      ctx.fillText('X2 BOOST', g.x + g.w/2, g.y + g.h/2 + 3);
      if (g.pulse > 0) g.pulse -= 0.05;
    });

    // Vẽ Multipliers
    state.multipliers.forEach(m => {
      ctx.fillStyle = m.color;
      ctx.globalAlpha = 0.2 + (m.pulse * 0.8);
      const r = 3;
      ctx.beginPath();
      ctx.moveTo(m.x + 1 + r, m.y);
      ctx.lineTo(m.x + m.w - 1 - r, m.y);
      ctx.quadraticCurveTo(m.x + m.w - 1, m.y, m.x + m.w - 1, m.y + r);
      ctx.lineTo(m.x + m.w - 1, m.y + m.h - r);
      ctx.quadraticCurveTo(m.x + m.w - 1, m.y + m.h, m.x + m.w - 1 - r, m.y + m.h);
      ctx.lineTo(m.x + 1 + r, m.y + m.h);
      ctx.quadraticCurveTo(m.x + 1, m.y + m.h, m.x + 1, m.y + m.h - r);
      ctx.lineTo(m.x + 1, m.y + r);
      ctx.quadraticCurveTo(m.x + 1, m.y, m.x + 1 + r, m.y);
      ctx.fill();
      
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#fff';
      const fontSize = Math.min(8, m.w / 2.5);
      ctx.font = `bold ${fontSize}px monospace`;
      ctx.textAlign = 'center';
      const displayVal = m.value >= 100 ? Math.floor(m.value) : m.value;
      ctx.fillText(displayVal, m.x + m.w / 2, m.y + m.h / 2 + (fontSize/3));
      if (m.pulse > 0) m.pulse -= 0.04;
    });

    // Vẽ Particles
    state.particles.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 1.2, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;

    // Vẽ Bóng
    state.balls.forEach(b => {
      const color = b.currentMult >= 4 ? COLORS.ballMega : (b.currentMult >= 2 ? COLORS.ballSuper : COLORS.ball);
      ctx.fillStyle = color;
      ctx.shadowBlur = b.currentMult > 1 ? 10 : 0;
      ctx.shadowColor = color;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  };

  const animate = (time) => {
    update(time);
    draw();
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    const handleResize = () => {
      const container = canvasRef.current?.parentElement;
      if (!container) return;
      canvasRef.current.width = container.clientWidth;
      canvasRef.current.height = container.clientHeight;
      gameState.current.width = container.clientWidth;
      gameState.current.height = container.clientHeight;
      generateLayout();
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(requestRef.current);
    };
  }, [generateLayout]);

  const deployBall = () => {
    initAudio();
    if (balance >= bet) {
      setBalance(b => b - bet);
      executeDrop(bet);
      setMessage("TẤN CÔNG!");
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#020617] flex items-center justify-center p-0 md:p-6 font-sans">
      <style>{`
        .phone-frame {
          width: 100%; height: 100vh;
          background: #05070a;
          position: relative; overflow: hidden;
          display: flex; flex-direction: column;
        }
        @media (min-width: 768px) {
          .phone-frame {
            width: 380px; height: 800px;
            border-radius: 48px;
            border: 12px solid #1e293b;
            box-shadow: 0 0 0 2px #334155, 0 40px 100px -20px rgba(0,0,0,0.8);
          }
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .glitch-text { animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
      `}</style>

      <div className="phone-frame">
        {/* Header HUD */}
        <header className="px-5 pt-10 md:pt-8 pb-4 flex justify-between items-center bg-[#0f172a]/95 border-b border-blue-500/20 z-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600/20 rounded-xl border border-blue-500/50 flex items-center justify-center">
              <Shield size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-[10px] text-blue-400/70 font-bold uppercase tracking-tighter">Ngân quỹ</p>
              <p className="text-sm font-black text-white tabular-nums tracking-tight">
                {balance.toLocaleString()} <span className="text-[10px] text-blue-400">CR</span>
              </p>
            </div>
          </div>
          <button onClick={() => setIsMuted(!isMuted)} className="w-10 h-10 flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-colors">
            {isMuted ? <VolumeX size={18} className="text-slate-500" /> : <Volume2 size={18} className="text-blue-400" />}
          </button>
        </header>

        {/* Stats Strip */}
        <div className="px-5 py-2 bg-slate-900/50 flex justify-between items-center border-b border-white/5">
           <div className="flex gap-4">
              <div className="flex items-center gap-1">
                <Target size={12} className="text-slate-500" />
                <span className="text-[10px] font-bold text-slate-400">{stats.totalDrops}</span>
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp size={12} className="text-emerald-500" />
                <span className="text-[10px] font-bold text-emerald-400">+{stats.totalWins.toLocaleString()}</span>
              </div>
           </div>
           <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest glitch-text">{message}</span>
           </div>
        </div>

        {/* Game Area */}
        <main className="flex-grow flex flex-col relative overflow-hidden bg-[radial-gradient(circle_at_center,_#0f172a_0%,_#020617_100%)]">
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'linear-gradient(#475569 1px, transparent 1px), linear-gradient(90deg, #475569 1px, transparent 1px)', backgroundSize: '25px 25px' }}></div>
          
          <canvas ref={canvasRef} className="w-full h-full block touch-none z-10"></canvas>
          
          {/* Lịch sử mới hiển thị thay cho history cũ */}
          <div className="absolute bottom-4 left-0 right-0 z-30 px-3 pointer-events-none">
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
              {history.length === 0 ? (
                 <div className="w-full text-center py-2 bg-black/40 backdrop-blur rounded-xl border border-white/5">
                    <span className="text-[10px] text-slate-600 font-bold uppercase tracking-wider">Đang chờ lượt thả...</span>
                 </div>
              ) : (
                history.map((h, i) => (
                  <div 
                    key={h.id} 
                    className="flex-shrink-0 flex items-center gap-2 px-3 py-1.5 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl animate-in slide-in-from-right-8 duration-500"
                    style={{ opacity: 1 - (i * 0.12) }}
                  >
                    <span className="text-[11px] font-black" style={{ color: h.color }}>{h.mult}x</span>
                    <div className="w-[1px] h-3 bg-white/10"></div>
                    <span className="text-[10px] font-bold text-white whitespace-nowrap">+{h.win}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-[#0f172a] border-t border-blue-500/30 p-5 pb-10 space-y-5">
          <div className="flex items-center gap-4">
            <div className="flex-grow bg-black/40 p-3 rounded-2xl border border-white/5">
              <div className="flex justify-between items-center mb-1">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Định mức cược</label>
                <Zap size={10} className="text-blue-400" />
              </div>
              <div className="flex items-center justify-between">
                <input 
                  type="number" 
                  value={bet} 
                  onChange={(e) => setBet(Math.max(100, parseInt(e.target.value) || 0))}
                  className="bg-transparent text-white font-black text-lg outline-none w-full"
                />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              {[1, 2, 5].map(m => (
                <button key={m} onClick={() => setBet(b => b * m)} className="px-3 py-1 text-[10px] font-bold bg-white/5 hover:bg-blue-600/20 rounded-lg border border-white/10 transition-all">
                  x{m}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <button 
              disabled={isAuto}
              onClick={deployBall}
              className={`flex-1 group relative overflow-hidden py-4 rounded-2xl font-black text-sm tracking-widest transition-all active:scale-95 ${isAuto ? 'bg-slate-800 text-slate-600' : 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)]'}`}
            >
              <div className="relative z-10 flex items-center justify-center gap-2">
                <Target size={18} />
                TRIỂN KHAI
              </div>
            </button>
            
            <button 
              onClick={() => setIsAuto(!isAuto)}
              className={`w-20 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all ${isAuto ? 'bg-red-500/10 border-red-500 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]' : 'bg-white/5 border-white/10 text-white'}`}
            >
              {isAuto ? <Square size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
              <span className="text-[8px] font-black uppercase tracking-tighter">{isAuto ? 'STOP' : 'AUTO'}</span>
            </button>
          </div>
          
          <div className="flex justify-around items-center pt-2">
            <div className="flex flex-col items-center gap-1">
              <Trophy size={14} className="text-yellow-500" />
              <span className="text-[8px] text-slate-500 font-bold uppercase">Rank: S1</span>
            </div>
            <div className="w-[1px] h-4 bg-white/5"></div>
            <div className="flex flex-col items-center gap-1 text-blue-400">
              <Clock size={14} />
              <span className="text-[8px] font-bold uppercase">Live Map</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}