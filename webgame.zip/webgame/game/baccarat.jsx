import React, { useState, useEffect, useRef } from 'react';
import { Wallet, Trophy, Star, Clock, Coins, ChevronRight } from 'lucide-react';

const CHIPS = [
  { value: 10000, label: '10K', color: '#64748b' },
  { value: 50000, label: '50K', color: '#94a3b8' },
  { value: 100000, label: '100K', color: '#3b82f6' },
  { value: 500000, label: '500K', color: '#10b981' },
  { value: 1000000, label: '1M', color: '#f59e0b' },
  { value: 5000000, label: '5M', color: '#ef4444' },
  { value: 10000000, label: '10M', color: '#8b5cf6' },
];

const SUITS = [
  { symbol: '♠', color: 'black' },
  { symbol: '♣', color: 'black' },
  { symbol: '♥', color: 'red' },
  { symbol: '♦', color: 'red' }
];
const VALUES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

const SESSION_TIME = 15;

const getCardValue = (card) => {
  if (!card) return 0;
  if (['10', 'J', 'Q', 'K'].includes(card.val)) return 0;
  if (card.val === 'A') return 1;
  return parseInt(card.val);
};

const calculateScore = (cards) => {
  const total = cards.reduce((sum, card) => sum + getCardValue(card), 0);
  return total % 10;
};

const Card = ({ card, isFlipped, index, isDealing }) => {
  const [arrived, setArrived] = useState(false);
  const isThirdCard = index === 2;

  useEffect(() => {
    if (isDealing && card) {
      // Tạo độ trễ ngẫu nhiên nhẹ để không bị "cứng"
      const delay = index * 150; 
      const timer = setTimeout(() => setArrived(true), delay);
      return () => clearTimeout(timer);
    } else if (!isDealing) {
      setArrived(false);
    }
  }, [isDealing, card, index]);

  if (!card) return null;

  const cardStyle = {
    perspective: '1200px',
    transform: arrived 
      ? (isThirdCard ? 'rotate(90deg) translateY(-8px)' : 'translate(0, 0)') 
      : 'translate(300px, -500px) rotate(20deg)',
    opacity: arrived ? 1 : 0,
    zIndex: 10 + index,
    // Sử dụng cubic-bezier để tạo hiệu ứng mượt mà và có độ nảy nhẹ
    transition: 'transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.4s ease-out',
  };

  return (
    <div 
      className={`relative w-10 h-14 md:w-20 md:h-28 flex-shrink-0 ${isThirdCard ? 'mt-6 md:mt-0 md:ml-4' : ''}`}
      style={cardStyle}
    >
      <div className={`relative w-full h-full duration-1000 preserve-3d transition-transform cubic-bezier(0.4, 0, 0.2, 1) ${isFlipped ? 'rotate-y-180' : ''}`}>
        {/* Mặt sau (Card Back) */}
        <div className="absolute inset-0 backface-hidden rounded-sm md:rounded-lg border border-yellow-500/20 bg-[#1a0a0a] shadow-2xl flex items-center justify-center overflow-hidden">
           <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
           <div className="w-full h-full border-4 border-yellow-600/10 m-1 rounded-sm flex items-center justify-center">
              <Star className="text-yellow-600/20 animate-pulse" size={20} />
           </div>
        </div>
        
        {/* Mặt trước (Card Front) */}
        <div className="absolute inset-0 backface-hidden rotate-y-180 rounded-sm md:rounded-lg bg-white border border-slate-200 shadow-xl text-black overflow-hidden">
          <div className={`absolute top-1 left-1 flex flex-col items-center leading-none ${card.color === 'red' ? 'text-red-600' : 'text-slate-900'}`}>
            <span className="text-[10px] md:text-sm font-black">{card.val}</span>
            <span className="text-[8px] md:text-xs">{card.suit}</span>
          </div>
          
          <div className="absolute inset-0 flex items-center justify-center text-lg md:text-4xl drop-shadow-sm">
            <span className={card.color === 'red' ? 'text-red-600' : 'text-slate-900'}>{card.suit}</span>
          </div>
          
          <div className={`absolute bottom-1 right-1 flex flex-col items-center leading-none rotate-180 ${card.color === 'red' ? 'text-red-600' : 'text-slate-900'}`}>
            <span className="text-[10px] md:text-sm font-black">{card.val}</span>
            <span className="text-[8px] md:text-xs">{card.suit}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [balance, setBalance] = useState(1000000000); 
  const [selectedChip, setSelectedChip] = useState(100000);
  const [bets, setBets] = useState({ PLAYER: 0, BANKER: 0, TIE: 0 });
  const [gameStatus, setGameStatus] = useState('IDLE'); 
  const [winner, setWinner] = useState(null);
  const [hands, setHands] = useState({ player: [], banker: [] });
  const [history, setHistory] = useState([]);
  const [message, setMessage] = useState("MỜI ĐẶT CƯỢC");
  const [revealed, setRevealed] = useState({ player: false, banker: false, p3: false, b3: false });
  const [isDealing, setIsDealing] = useState(false);
  const [timeLeft, setTimeLeft] = useState(SESSION_TIME);
  const timerRef = useRef(null);

  useEffect(() => {
    if (gameStatus === 'IDLE') {
      setWinner(null);
      setTimeLeft(SESSION_TIME);
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            startDeal();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [gameStatus]);

  const createCard = () => {
    const suit = SUITS[Math.floor(Math.random() * 4)];
    const val = VALUES[Math.floor(Math.random() * 13)];
    return { suit: suit.symbol, val, color: suit.color };
  };

  const startDeal = async () => {
    setIsDealing(false); 
    setHands({ player: [], banker: [] });
    setRevealed({ player: false, banker: false, p3: false, b3: false });
    setGameStatus('DEALING');
    
    await new Promise(r => setTimeout(r, 600));
    setIsDealing(true);
    setMessage("BẮT ĐẦU CHIA BÀI...");

    const p1 = createCard(); const b1 = createCard();
    const p2 = createCard(); const b2 = createCard();

    // Chia bài với nhịp độ mượt mà
    setHands(h => ({ ...h, player: [p1] })); await new Promise(r => setTimeout(r, 500));
    setHands(h => ({ ...h, banker: [b1] })); await new Promise(r => setTimeout(r, 500));
    setHands(h => ({ ...h, player: [p1, p2] })); await new Promise(r => setTimeout(r, 500));
    setHands(h => ({ ...h, banker: [b1, b2] })); await new Promise(r => setTimeout(r, 800));

    // Lật bài từ từ để tạo kịch tính
    setMessage("PLAYER LẬT...");
    setRevealed(prev => ({ ...prev, player: true })); await new Promise(r => setTimeout(r, 1200));

    setMessage("BANKER LẬT...");
    setRevealed(prev => ({ ...prev, banker: true })); await new Promise(r => setTimeout(r, 1200));
    
    let pHand = [p1, p2];
    let bHand = [b1, b2];
    let pScore = calculateScore(pHand);
    let bScore = calculateScore(bHand);

    // Xử lý rút lá thứ 3
    if (pScore < 8 && bScore < 8) {
      if (pScore <= 5) {
        setMessage("PLAYER RÚT THÊM...");
        const p3 = createCard();
        pHand.push(p3);
        setHands(h => ({ ...h, player: [...pHand] }));
        await new Promise(r => setTimeout(r, 1000));
        setRevealed(prev => ({ ...prev, p3: true }));
        await new Promise(r => setTimeout(r, 1000));
        pScore = calculateScore(pHand);
      }
      
      if (bScore <= 5) {
        setMessage("BANKER RÚT THÊM...");
        const b3 = createCard();
        bHand.push(b3);
        setHands(h => ({ ...h, banker: [...bHand] }));
        await new Promise(r => setTimeout(r, 1000));
        setRevealed(prev => ({ ...prev, b3: true }));
        await new Promise(r => setTimeout(r, 1000));
        bScore = calculateScore(bHand);
      }
    }

    handleResult(pScore, bScore);
  };

  const handleResult = (p, b) => {
    let res = "TIE";
    if (p > b) res = "PLAYER";
    else if (b > p) res = "BANKER";

    setWinner(res);
    setGameStatus('RESULT');
    setHistory(prev => [...prev, res].slice(-100));

    let win = 0;
    if (res === "PLAYER") win = bets.PLAYER * 2;
    if (res === "BANKER") win = bets.BANKER * 1.95;
    if (res === "TIE") win = bets.TIE * 9;

    if (win > 0) {
      setBalance(curr => curr + win);
      setMessage(`CHÚC MỪNG! THẮNG ${Math.floor(win).toLocaleString()}₫`);
    } else {
      setMessage(res === "TIE" ? "HÒA - HOÀN TIỀN" : `${res} THẮNG`);
    }

    setTimeout(() => {
      setBets({ PLAYER: 0, BANKER: 0, TIE: 0 });
      setGameStatus('IDLE');
      setIsDealing(false);
      setMessage("MỜI ĐẶT CƯỢC");
    }, 5000);
  };

  const handleBet = (type) => {
    if (gameStatus !== 'IDLE' || timeLeft === 0) return;
    if (balance >= selectedChip) {
      setBalance(b => b - selectedChip);
      setBets(prev => ({ ...prev, [type]: prev[type] + selectedChip }));
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 font-sans select-none flex flex-col items-center overflow-x-hidden">
      <style>{`
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .felt-surface {
          background: radial-gradient(circle at 50% 0%, #064e3b 0%, #022c22 100%);
          box-shadow: inset 0 0 60px rgba(0,0,0,0.5);
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .bet-box-active {
           box-shadow: 0 0 25px rgba(245, 158, 11, 0.5), inset 0 0 15px rgba(245, 158, 11, 0.2);
           border-color: rgba(245, 158, 11, 0.8) !important;
           transform: translateY(-2px);
        }
        .card-shadow {
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.4);
        }
        @keyframes subtle-pulse {
          0%, 100% { opacity: 0.8; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }
        .pulse-text { animation: subtle-pulse 2s infinite ease-in-out; }
      `}</style>

      {/* Top Navigation */}
      <header className="w-full max-w-2xl px-5 py-4 flex justify-between items-center bg-[#0f172a]/80 backdrop-blur-xl border-b border-white/5 sticky top-0 z-[100]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-amber-400 to-yellow-600 rounded-xl flex items-center justify-center shadow-lg shadow-yellow-900/20">
            <Trophy size={20} className="text-amber-950" />
          </div>
          <div className="flex flex-col">
            <span className="font-black text-sm tracking-widest text-white leading-none">MACAU LUXURY</span>
            <span className="text-[10px] text-amber-500 font-bold uppercase tracking-tighter">Baccarat Private Club</span>
          </div>
        </div>
        <div className="flex items-center gap-3 bg-slate-950/60 border border-white/10 px-4 py-2 rounded-2xl shadow-inner">
          <Wallet size={16} className="text-amber-500" />
          <span className="text-sm font-mono font-bold text-white tracking-tight">{balance.toLocaleString()}₫</span>
        </div>
      </header>

      {/* Game Info Bar */}
      <div className="w-full max-w-2xl px-5 py-3 flex justify-between items-center bg-slate-900/30">
        <div className="flex items-center gap-3">
           <div className={`flex items-center gap-2 px-3 py-1 rounded-full border transition-colors ${timeLeft <= 5 && gameStatus === 'IDLE' ? 'bg-red-500/10 border-red-500/50' : 'bg-blue-500/10 border-blue-500/50'}`}>
              <Clock size={14} className={timeLeft <= 5 && gameStatus === 'IDLE' ? 'text-red-500 animate-pulse' : 'text-blue-400'} />
              <span className={`text-[11px] font-black uppercase tracking-widest ${timeLeft <= 5 && gameStatus === 'IDLE' ? 'text-red-500' : 'text-slate-300'}`}>
                {gameStatus === 'IDLE' ? `HẾT HẠN: ${timeLeft}s` : 'ĐANG DIỄN RA'}
              </span>
           </div>
        </div>
        <div className="flex gap-1.5 items-center">
            <span className="text-[10px] text-slate-500 font-bold mr-2 uppercase">Lịch sử</span>
            <div className="flex -space-x-1">
              {history.slice(-8).map((h, i) => (
                <div key={i} className={`w-3 h-3 rounded-full border border-slate-900 shadow-sm ${h === 'PLAYER' ? 'bg-blue-500' : h === 'BANKER' ? 'bg-red-500' : 'bg-emerald-500'}`} />
              ))}
            </div>
        </div>
      </div>

      <main className="flex-grow w-full max-w-2xl flex flex-col p-4 gap-4">
        
        {/* Gaming Table */}
        <div className="relative bg-[#0f172a] rounded-[2rem] p-6 border border-white/5 shadow-2xl min-h-[260px] md:min-h-[340px] flex items-center justify-center overflow-hidden">
           <div className="absolute inset-0 opacity-[0.02] flex items-center justify-center pointer-events-none">
              <Star size={300} />
           </div>
           
           <div className="grid grid-cols-2 w-full gap-8 relative z-10">
              {/* Player Zone */}
              <div className="flex flex-col items-center gap-4">
                 <div className={`text-[11px] font-black px-4 py-1 rounded-full border shadow-lg transition-all duration-700 ${revealed.player ? 'bg-blue-600 border-blue-400 text-white' : 'bg-slate-800 border-white/10 text-slate-500'}`}>
                   PLAYER: {revealed.player ? calculateScore(hands.player) : '??'}
                 </div>
                 <div className="flex flex-wrap justify-center gap-2 md:gap-4 min-h-[100px]">
                   {hands.player.map((c, i) => (
                     <Card key={`p-${i}`} card={c} isFlipped={i === 2 ? revealed.p3 : revealed.player} index={i} isDealing={isDealing} />
                   ))}
                 </div>
              </div>

              {/* Banker Zone */}
              <div className="flex flex-col items-center gap-4">
                 <div className={`text-[11px] font-black px-4 py-1 rounded-full border shadow-lg transition-all duration-700 ${revealed.banker ? 'bg-red-600 border-red-400 text-white' : 'bg-slate-800 border-white/10 text-slate-500'}`}>
                   BANKER: {revealed.banker ? calculateScore(hands.banker) : '??'}
                 </div>
                 <div className="flex flex-wrap justify-center gap-2 md:gap-4 min-h-[100px]">
                   {hands.banker.map((c, i) => (
                     <Card key={`b-${i}`} card={c} isFlipped={i === 2 ? revealed.b3 : revealed.banker} index={i} isDealing={isDealing} />
                   ))}
                 </div>
              </div>
           </div>

           {/* Central Message */}
           <div className="absolute bottom-6 inset-x-0 flex justify-center pointer-events-none">
              <div className="bg-black/60 backdrop-blur-md px-6 py-1 rounded-full border border-white/10">
                 <span className="text-[10px] font-black text-amber-500 tracking-[0.3em] uppercase pulse-text">
                   {message}
                 </span>
              </div>
           </div>
        </div>

        {/* Bet Options */}
        <div className="grid grid-cols-3 gap-3 h-28 md:h-36">
           <button onClick={() => handleBet('PLAYER')} className={`rounded-2xl border border-white/5 felt-surface flex flex-col items-center justify-center relative transition-all duration-300 active:scale-95 ${winner === 'PLAYER' ? 'bet-box-active' : ''}`}>
              <span className="text-lg md:text-2xl font-black text-blue-500 tracking-tighter">PLAYER</span>
              <span className="text-[10px] text-white/30 font-bold mt-1 tracking-widest">PAY 1:1</span>
              {bets.PLAYER > 0 && (
                <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-[10px] font-black text-white shadow-xl animate-bounce">
                  {(bets.PLAYER/1000)}K
                </div>
              )}
           </button>
           <button onClick={() => handleBet('TIE')} className={`rounded-2xl border border-white/5 felt-surface flex flex-col items-center justify-center relative transition-all duration-300 active:scale-95 ${winner === 'TIE' ? 'bet-box-active' : ''}`}>
              <span className="text-lg md:text-2xl font-black text-emerald-500 tracking-tighter">TIE</span>
              <span className="text-[10px] text-white/30 font-bold mt-1 tracking-widest">PAY 1:8</span>
              {bets.TIE > 0 && (
                <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-emerald-600 border-2 border-white flex items-center justify-center text-[10px] font-black text-white shadow-xl animate-bounce">
                  {(bets.TIE/1000)}K
                </div>
              )}
           </button>
           <button onClick={() => handleBet('BANKER')} className={`rounded-2xl border border-white/5 felt-surface flex flex-col items-center justify-center relative transition-all duration-300 active:scale-95 ${winner === 'BANKER' ? 'bet-box-active' : ''}`}>
              <span className="text-lg md:text-2xl font-black text-red-500 tracking-tighter">BANKER</span>
              <span className="text-[10px] text-white/30 font-bold mt-1 tracking-widest">PAY 1:0.95</span>
              {bets.BANKER > 0 && (
                <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-red-600 border-2 border-white flex items-center justify-center text-[10px] font-black text-white shadow-xl animate-bounce">
                  {(bets.BANKER/1000)}K
                </div>
              )}
           </button>
        </div>

        {/* Advanced Roadmap */}
        <div className="bg-slate-900/50 rounded-2xl p-4 border border-white/5">
           <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Roadmap Analysis</span>
              <div className="flex gap-4 text-[10px] font-bold">
                 <span className="text-blue-500">P: {history.filter(x=>x==='PLAYER').length}</span>
                 <span className="text-red-500">B: {history.filter(x=>x==='BANKER').length}</span>
                 <span className="text-emerald-500">T: {history.filter(x=>x==='TIE').length}</span>
              </div>
           </div>
           <div className="grid grid-rows-6 grid-flow-col gap-1.5 h-20 overflow-x-auto no-scrollbar scroll-smooth">
              {history.map((h, i) => (
                <div key={i} className={`w-3 h-3 rounded-full flex-shrink-0 flex items-center justify-center text-[6px] font-black text-white transition-all duration-500 ${h === 'PLAYER' ? 'bg-blue-600' : h === 'BANKER' ? 'bg-red-600' : 'bg-emerald-600'}`}>
                  {h[0]}
                </div>
              ))}
              {[...Array(Math.max(0, 120 - history.length))].map((_, i) => (
                <div key={i} className="w-3 h-3 rounded-full bg-slate-800/20 flex-shrink-0" />
              ))}
           </div>
        </div>
      </main>

      {/* Modern Control Bar */}
      <footer className="w-full max-w-2xl bg-[#0f172a] border-t border-white/10 p-5 pb-8 flex flex-col gap-6">
        <div className="flex gap-3 overflow-x-auto no-scrollbar py-2 px-1">
          {CHIPS.map(chip => (
            <button 
              key={chip.value}
              onClick={() => setSelectedChip(chip.value)}
              className={`flex-shrink-0 w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-300 shadow-xl ${selectedChip === chip.value ? 'scale-110 -translate-y-2 border-white ring-4 ring-white/10' : 'border-transparent opacity-40 grayscale-[0.5]'}`}
              style={{ background: `radial-gradient(circle at 35% 35%, ${chip.color}, #000 160%)` }}
            >
              <div className="w-full h-full rounded-full border border-dashed border-white/20 flex items-center justify-center">
                <span className="text-[9px] font-black text-white">{chip.label}</span>
              </div>
            </button>
          ))}
        </div>
        
        <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl border border-white/5">
           <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Mức cược hiện tại</span>
              <div className="flex items-center gap-2">
                 <Coins size={14} className="text-amber-500" />
                 <span className="text-lg font-mono font-black text-amber-500">{selectedChip.toLocaleString()}₫</span>
              </div>
           </div>
           <button onClick={() => setBalance(prev => prev + 1000000000)} className="group bg-gradient-to-r from-amber-500 to-yellow-600 text-amber-950 font-black text-xs px-6 py-3 rounded-xl shadow-lg shadow-amber-900/20 active:scale-95 transition-all flex items-center gap-2">
             NẠP THÊM
             <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
           </button>
        </div>
      </footer>
    </div>
  );
}