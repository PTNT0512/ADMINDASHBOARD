import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Volume2, VolumeX, History, Play, Square, Wallet, Shield } from 'lucide-react';

// --- Cấu hình hằng số ---
const GRAVITY = 0.35; 
const BOUNCE_DAMPENING = 0.5;
const HORIZONTAL_RANDOMNESS = 0.3;
const AUTO_DROP_INTERVAL = 180; 

const COLORS = {
  bg: '#050505',
  pin: '#374151',
  ball: '#ef4444',
  ballSuper: '#06b6d4',
  highMult: '#b91c1c',
  medMult: '#b45309',
  lowMult: '#15803d',
  gate: '#06b6d4',
  text: '#10b981'
};

const FIXED_ROW_COUNT = 14;
const FIXED_MULTIPLIERS = [58, 15, 7, 4, 1.9, 1, 0.5, 0.2, 0.5, 1, 1.9, 4, 7, 15, 58];

export default function App() {
  const [balance, setBalance] = useState(10000);
  const [bet, setBet] = useState(10);
  const [logs, setLogs] = useState([]);
  const [isMuted, setIsMuted] = useState(false);
  const [isAuto, setIsAuto] = useState(false);
  const [fps, setFps] = useState(60);

  const canvasRef = useRef(null);
  const requestRef = useRef(null);
  const audioCtxRef = useRef(null);
  
  const gameState = useRef({
    width: 0,
    height: 0,
    balls: [],
    pins: [],
    particles: [],
    multipliers: [],
    gates: [],
    layoutGap: 20,
    pegSize: 2,
    ballSize: 5,
    lastTime: 0,
    autoEnabled: false,
    lastAutoDrop: 0,
    currentBalance: 10000,
    currentBet: 10,
    startY: 60
  });

  useEffect(() => { gameState.current.currentBalance = balance; }, [balance]);
  useEffect(() => { gameState.current.currentBet = bet; }, [bet]);
  useEffect(() => { gameState.current.autoEnabled = isAuto; }, [isAuto]);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtxRef.current = new AudioContext();
    }
    if (audioCtxRef.current.state === 'suspended') audioCtxRef.current.resume();
  };

  const playSound = useCallback((type) => {
    if (isMuted || !audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    const now = ctx.currentTime;

    if (type === 'hit') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(400, now);
      gain.gain.setValueAtTime(0.01, now);
      osc.start(now);
      osc.stop(now + 0.03);
    } else if (type === 'score') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      gain.gain.setValueAtTime(0.03, now);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  }, [isMuted]);

  const generateLayout = useCallback(() => {
    const state = gameState.current;
    if (!state.width || !state.height) return;

    const { width, height } = state;
    state.pins = [];
    state.multipliers = [];
    state.gates = [];

    const isMobile = width < 768;
    const pinsInLastRow = FIXED_ROW_COUNT + 2;
    const paddingX = 20;
    const paddingY = isMobile ? 120 : 160;
    
    let gap = Math.min((width - paddingX) / (pinsInLastRow + 1), (height - paddingY) / FIXED_ROW_COUNT);
    gap = Math.min(Math.max(gap, 18), 40);

    state.layoutGap = gap;
    state.ballSize = gap * 0.22;
    state.startY = isMobile ? 40 : 80;

    for (let r = 0; r < FIXED_ROW_COUNT; r++) {
      const pinsInRow = r + 3;
      const rowWidth = (pinsInRow - 1) * gap;
      const startX = (width - rowWidth) / 2;
      for (let c = 0; c < pinsInRow; c++) {
        state.pins.push({ x: startX + c * gap, y: state.startY + r * gap, pulse: 0 });
      }
    }

    const gateRow = 7;
    const pinsInGateRow = gateRow + 3;
    const gateRowWidth = (pinsInGateRow - 1) * gap;
    const gateRowStartX = (width - gateRowWidth) / 2;

    state.gates.push({
      x: width / 2 - (gap * 0.45),
      y: state.startY + gateRow * gap + (gap / 2) - (gap * 0.2),
      w: gap * 0.9,
      h: gap * 0.4,
      pulse: 0,
      minX: gateRowStartX + gap * 0.5, 
      maxX: gateRowStartX + gateRowWidth - gap * 1.5,
      direction: 1, 
      speed: isMobile ? 0.8 : 1.2,
      isPaused: false,
      pauseTimer: 0
    });

    const bucketW = gap;
    const totalW = FIXED_MULTIPLIERS.length * bucketW;
    const startXMult = (width - totalW) / 2;

    FIXED_MULTIPLIERS.forEach((val, i) => {
      let color = val >= 10 ? COLORS.highMult : (val >= 2 ? COLORS.medMult : COLORS.lowMult);
      state.multipliers.push({
        x: startXMult + i * bucketW,
        y: height - (isMobile ? 50 : 70),
        w: bucketW,
        h: isMobile ? 35 : 45,
        value: val,
        color: color,
        pulse: 0
      });
    });
  }, []);

  const executeDrop = useCallback((betAmount) => {
    const state = gameState.current;
    state.balls.push({
      x: state.width / 2 + (Math.random() - 0.5) * 4,
      y: state.startY - 30,
      vx: (Math.random() - 0.5) * 0.4,
      vy: 1,
      radius: state.ballSize,
      betValue: betAmount,
      currentMult: 1,
      hitGates: [],
      trail: []
    });
  }, []);

  const update = (time) => {
    const state = gameState.current;
    
    // FPS counter
    const dt = time - state.lastTime;
    if (dt > 0) setFps(Math.round(1000/dt));
    state.lastTime = time;

    if (state.autoEnabled && time - state.lastAutoDrop > AUTO_DROP_INTERVAL) {
      if (state.currentBalance >= state.currentBet) {
        state.currentBalance -= state.currentBet;
        setBalance(state.currentBalance);
        executeDrop(state.currentBet);
        state.lastAutoDrop = time;
      } else {
        setIsAuto(false);
      }
    }

    state.gates.forEach(g => {
      if (g.isPaused) {
        g.pauseTimer -= 16;
        if (g.pauseTimer <= 0) g.isPaused = false;
      } else {
        g.x += g.direction * g.speed;
        if (g.x <= g.minX || g.x >= g.maxX) {
          g.direction *= -1;
          if (Math.random() > 0.7) {
            g.isPaused = true;
            g.pauseTimer = 800 + Math.random() * 1500;
          }
        }
      }
    });

    // Update Particles
    for (let i = state.particles.length - 1; i >= 0; i--) {
      const p = state.particles[i];
      p.x += p.vx; p.y += p.vy; p.life -= 0.02;
      if (p.life <= 0) state.particles.splice(i, 1);
    }

    const bucketW = state.layoutGap;
    const totalW = FIXED_MULTIPLIERS.length * bucketW;
    const startXMult = (state.width - totalW) / 2;

    for (let i = state.balls.length - 1; i >= 0; i--) {
      let b = state.balls[i];
      b.vy += GRAVITY;
      b.x += b.vx; 
      b.y += b.vy;

      b.trail.push({x: b.x, y: b.y});
      if (b.trail.length > 5) b.trail.shift();

      // Va chạm Cổng x2
      state.gates.forEach((g, idx) => {
        if (b.x > g.x && b.x < g.x + g.w && b.y > g.y && b.y < g.y + g.h && !b.hitGates.includes(idx)) {
          b.hitGates.push(idx);
          b.currentMult *= 2;
          g.pulse = 1;
          playSound('score');
          for(let k=0; k<8; k++) state.particles.push({x: b.x, y: b.y, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, life: 1, color: COLORS.gate});
        }
      });

      // Va chạm Chốt
      state.pins.forEach(p => {
        const dx = b.x - p.x;
        const dy = b.y - p.y;
        const distSq = dx * dx + dy * dy;
        const minDist = b.radius + state.pegSize;
        if (distSq < minDist * minDist) {
          p.pulse = 1;
          playSound('hit');
          const dist = Math.sqrt(distSq);
          const nx = dx / dist;
          const ny = dy / dist;
          const speed = Math.sqrt(b.vx * b.vx + b.vy * b.vy) * BOUNCE_DAMPENING;
          const angle = Math.atan2(ny, nx);
          b.vx = Math.cos(angle + (Math.random() - 0.5) * HORIZONTAL_RANDOMNESS) * speed;
          b.vy = Math.sin(angle) * speed;
          b.x = p.x + nx * (minDist + 0.1);
          b.y = p.y + ny * (minDist + 0.1);
        }
      });

      // Kết thúc lượt
      const finishLine = state.height - (state.width < 768 ? 50 : 70);
      if (b.y > finishLine) {
        const idx = Math.floor((b.x - startXMult) / bucketW);
        const mIdx = Math.max(0, Math.min(idx, state.multipliers.length - 1));
        const m = state.multipliers[mIdx];
        const totalWin = b.betValue * m.value * b.currentMult;
        setBalance(prev => prev + totalWin);
        setLogs(prev => [{ id: Math.random(), mult: m.value * b.currentMult, win: totalWin }, ...prev].slice(0, 15));
        m.pulse = 1;
        for(let k=0; k<12; k++) state.particles.push({x: b.x, y: finishLine, vx: (Math.random()-0.5)*5, vy: -(Math.random()*5), life: 1, color: m.color});
        state.balls.splice(i, 1);
      }
    }
  };

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const state = gameState.current;
    
    // Clear with slight trail
    ctx.fillStyle = 'rgba(5, 5, 5, 0.4)';
    ctx.fillRect(0, 0, state.width, state.height);

    // Draw Grid (Radar Style)
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.05)';
    ctx.lineWidth = 1;
    for(let i=0; i<state.width; i+=20) { ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,state.height); ctx.stroke(); }
    for(let i=0; i<state.height; i+=20) { ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(state.width,i); ctx.stroke(); }

    state.particles.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, 2, 2);
    });
    ctx.globalAlpha = 1;

    state.pins.forEach(p => {
      ctx.fillStyle = p.pulse > 0 ? '#10b981' : COLORS.pin;
      ctx.beginPath();
      ctx.arc(p.x, p.y, state.pegSize + (p.pulse * 2), 0, Math.PI * 2);
      ctx.fill();
      if (p.pulse > 0) p.pulse -= 0.1;
    });

    state.gates.forEach(g => {
      ctx.strokeStyle = g.isPaused ? '#475569' : COLORS.gate;
      ctx.lineWidth = 2;
      ctx.strokeRect(g.x, g.y, g.w, g.h);
      ctx.fillStyle = g.isPaused ? 'rgba(71, 85, 105, 0.2)' : `rgba(6, 182, 212, ${0.1 + g.pulse * 0.4})`;
      ctx.fillRect(g.x, g.y, g.w, g.h);
      ctx.fillStyle = g.isPaused ? '#64748b' : '#fff';
      ctx.font = 'bold 10px "Share Tech Mono"';
      ctx.textAlign = 'center';
      ctx.fillText('x2', g.x + g.w/2, g.y + g.h/2 + 4);
      if (g.pulse > 0) g.pulse -= 0.1;
    });

    state.multipliers.forEach(m => {
      ctx.fillStyle = m.color;
      ctx.globalAlpha = 0.2 + (m.pulse * 0.8);
      ctx.fillRect(m.x + 1, m.y, m.w - 2, m.h);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#fff';
      ctx.font = `bold ${Math.floor(m.w * 0.35)}px "Share Tech Mono"`;
      ctx.textAlign = 'center';
      ctx.fillText(m.value, m.x + m.w / 2, m.y + m.h / 2 + 5);
      if (m.pulse > 0) m.pulse -= 0.05;
    });

    state.balls.forEach(b => {
      ctx.beginPath();
      b.trail.forEach((t, idx) => {
        ctx.globalAlpha = idx / b.trail.length;
        ctx.fillStyle = b.currentMult > 1 ? COLORS.ballSuper : COLORS.ball;
        ctx.arc(t.x, t.y, b.radius * (idx/b.trail.length), 0, Math.PI*2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      ctx.shadowBlur = b.currentMult > 1 ? 10 : 0;
      ctx.shadowColor = COLORS.ballSuper;
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  };

  const animate = (time) => {
    update(time);
    draw();
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    const handleResize = () => {
      const container = canvasRef.current?.parentElement;
      if (!container) return;
      canvasRef.current.width = container.clientWidth;
      canvasRef.current.height = container.clientHeight;
      gameState.current.width = container.clientWidth;
      gameState.current.height = container.clientHeight;
      generateLayout();
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(requestRef.current);
    };
  }, [generateLayout]);

  const deployBall = () => {
    initAudio();
    if (balance >= bet) {
      setBalance(b => b - bet);
      executeDrop(bet);
    }
  };

  return (
    <div className="flex flex-col-reverse md:flex-row w-full h-screen bg-[#050505] text-[#e0f2fe] font-mono overflow-hidden select-none touch-none">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');
        body { font-family: 'Share Tech Mono', monospace; }
        .scanline {
          background: linear-gradient(to bottom, transparent 50%, rgba(16, 185, 129, 0.05) 50%);
          background-size: 100% 4px;
          pointer-events: none;
        }
        .clip-corner {
          clip-path: polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px);
        }
      `}</style>
      
      <div className="absolute inset-0 scanline z-50 pointer-events-none"></div>

      {/* Sidebar Tactical */}
      <div className="w-full md:w-72 bg-slate-900/90 border-t md:border-t-0 md:border-r border-emerald-900/50 p-4 z-20 shrink-0 backdrop-blur-md">
        <div className="hidden md:flex justify-between items-center mb-6">
          <h1 className="text-lg font-bold text-emerald-500 flex items-center gap-2 italic glow-text">
            <Shield size={18} /> /// TACTICAL OPS
          </h1>
          <button onClick={() => setIsMuted(!isMuted)} className="p-2 hover:bg-emerald-900/30 rounded text-emerald-500">
            {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>

        {/* Stats Row */}
        <div className="flex flex-row md:flex-col gap-3 mb-4">
          <div className="flex-1 bg-black/60 p-2 border border-emerald-900/50 rounded flex justify-between items-center relative overflow-hidden">
             <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
            <div className="flex flex-col ml-1">
              <span className="text-[10px] text-emerald-700 uppercase font-bold">ACCESS_CREDITS</span>
              <span className="text-emerald-400 font-bold text-sm md:text-xl tracking-tighter">${balance.toLocaleString()}</span>
            </div>
            <Wallet size={16} className="text-emerald-900" />
          </div>
          
          <div className="flex-1 md:hidden bg-black/60 p-2 border border-emerald-900/50 rounded">
             <span className="text-[10px] text-emerald-700 uppercase font-bold block mb-1">UNIT_COST</span>
             <input 
              type="number" 
              value={bet} 
              onChange={(e) => setBet(Math.max(1, parseInt(e.target.value) || 0))}
              className="w-full bg-transparent text-white font-bold outline-none"
            />
          </div>
        </div>

        {/* Desktop Bet Input */}
        <div className="hidden md:block mb-4">
          <label className="text-[10px] text-emerald-700 mb-1 block uppercase font-bold">Unit Deployment Cost</label>
          <input 
            type="number" 
            value={bet} 
            onChange={(e) => setBet(Math.max(1, parseInt(e.target.value) || 0))}
            className="w-full bg-black/60 border border-emerald-900/30 rounded p-2 text-white outline-none focus:border-emerald-500 transition-all"
          />
        </div>

        {/* Controls */}
        <div className="flex gap-2">
          <button 
            disabled={isAuto}
            onClick={deployBall} 
            className={`flex-1 py-3 md:py-4 clip-corner font-bold text-sm md:text-lg transition-all ${isAuto ? 'bg-slate-800 text-slate-600' : 'bg-emerald-600 text-black active:scale-95 shadow-[0_0_15px_rgba(16,185,129,0.4)]'}`}
          >
            DEPLOΥ
          </button>
          
          <button 
            onClick={() => { initAudio(); setIsAuto(!isAuto); }} 
            className={`px-4 md:w-full py-3 clip-corner font-bold border flex items-center justify-center gap-2 transition-all ${isAuto ? 'bg-red-900/20 border-red-500 text-red-500 animate-pulse' : 'bg-slate-800 border-emerald-900 text-emerald-500'}`}
          >
            {isAuto ? <Square size={16} fill="currentColor"/> : <Play size={16} fill="currentColor"/>}
            <span className="hidden md:inline">{isAuto ? 'HALT' : 'AUTO'}</span>
          </button>
        </div>

        {/* Logs Tactical */}
        <div className="hidden md:flex flex-col mt-6 h-48">
          <div className="text-[10px] text-emerald-800 border-b border-emerald-900/30 mb-2 pb-1 flex items-center gap-1 font-bold">
            <History size={10} /> MISSION_LOG
          </div>
          <div className="overflow-y-auto flex-1 space-y-1 pr-1 custom-scroll">
            {logs.map((log) => (
              <div key={log.id} className="flex justify-between text-[10px] p-2 bg-black/40 border-l border-emerald-900/50">
                <span className="text-emerald-700 tracking-widest">{log.mult}X</span>
                <span className="text-emerald-400 font-bold">+{log.win.toFixed(2)}$</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Game Area */}
      <div className="flex-1 relative bg-[#050505] flex items-center justify-center overflow-hidden">
        <canvas ref={canvasRef} className="w-full h-full block z-10 touch-none"></canvas>
        
        {/* HUD Elements */}
        <div className="absolute top-4 left-4 z-20 md:hidden flex items-center gap-2 pointer-events-none opacity-40">
          <Shield size={16} className="text-emerald-500" />
          <span className="text-[10px] font-bold text-emerald-500 tracking-[0.2em] uppercase">Tactical_Field_01</span>
        </div>

        <div className="absolute top-4 right-4 z-20 text-right pointer-events-none opacity-30">
          <div className="text-[8px] text-emerald-500 font-mono">SYS_CORE: STABLE</div>
          <div className="text-[8px] text-emerald-500 font-mono">FR_RATE: {fps}</div>
        </div>
      </div>
    </div>
  );
}